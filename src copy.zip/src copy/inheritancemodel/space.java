package inheritancemodel;

class space extends vehicle 
{
	boolean manned;
	String engine_type;
	double engine_thrust;
	
	space()
	{
		manned = false;
		engine_type = "Unknown";
		engine_thrust = -1;
	}
	
	space(boolean manned, String engine_type, double engine_thrust)
	{
		this.manned = manned;
		this.engine_type = engine_type;
		this.engine_thrust = engine_thrust;
	}
	
	public void spaceflight()
	{
		if (manned)
		{
			System.out.println("The vehicle is manned");
		}
		else
		{
			System.out.println("The vehicle is unmanned");
		}
		
		System.out.println("Engine type: " + engine_type);
		System.out.println("Engine thrust: " + engine_thrust);
	}
}
