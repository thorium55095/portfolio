package inheritancemodel;

public class Tester 
{

	public static void main(String[] args) 
	{
		vehicle v1 = new vehicle(20, 2457.8, 200);
		v1.transportation();
		
		System.out.println();
		
		air crnfl = new air("Agrarian", 30, false);
		crnfl.flight();
		
		System.out.println();
		
		land mpd = new land("Lawn mower", "2-sticks-2-wheels", "Agrarian");
		mpd.drive();
		
		System.out.println();
		
		space sat = new space(false, "No engine", 0);
		sat.spaceflight();
		
		System.out.println();
		
		water boat = new water("Paddles", "Boat", 0.4);
		boat.sail();
	}

}
