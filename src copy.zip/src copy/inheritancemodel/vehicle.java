package inheritancemodel;

public class vehicle 
{
	protected long seats;
	protected double capacity;
	protected double mspeed;
	
	vehicle()
	{
		seats = 0;
		capacity = 0;
		mspeed = 0;
	}
	
	vehicle (long seats, double capacity, double mspeed)
	{
		this.seats = seats;
		this.capacity = capacity;
		this.mspeed = mspeed;
	}
	
	public void transportation()
	{
		System.out.println("There are " + seats + " seats in the vehicle.");
		System.out.println("Capacity: " + capacity);
		System.out.println("Maximum speed: " + mspeed);
	}
}
