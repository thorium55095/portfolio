package inheritancemodel;

class water extends vehicle
{
	protected String engine_type;
	protected String vessel_type;
	protected double wl_height;
	
	water()
	{
		engine_type = "Unknown";
		vessel_type = "Unknown";
		wl_height = -1;
	}
	
	water (String engine_type, String vessel_type, double wl_height)
	{
		this.engine_type = engine_type;
		this.vessel_type = vessel_type;
		this.wl_height = wl_height;
	}
	
	public void sail()
	{
		System.out.println("Engine type: " + engine_type);
		System.out.println("Vessel type: " + vessel_type);
		if (wl_height == -1)
		{
			System.out.println("Waterline's Height is unknown");
		}
		else
		{
			System.out.println("Waterline's Height is " + wl_height);
		}
	}
}
