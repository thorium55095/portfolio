package inheritancemodel;

class air extends vehicle
{
	protected String ac_type;
	protected double to_time;
	protected boolean supersonic;
	
	air()
	{
		ac_type = "Unknown";
		to_time = -1;
		supersonic = false;
	}
	
	air (String ac_type, double to_time, boolean supersonic)
	{
		this.ac_type = ac_type;
		this.to_time = to_time;
		this.supersonic = supersonic;
	}
	
	public void flight()
	{
		System.out.println("Aircraft type: " + ac_type);
		System.out.println("Takeoff time: " + to_time);
		
		if (supersonic)
		{
			System.out.println("Aircraft is supersonic");
		}
		else
		{
			System.out.println("Aircraft is subsonic");
		}
	}
}
