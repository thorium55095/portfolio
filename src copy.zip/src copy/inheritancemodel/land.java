package inheritancemodel;

class land extends vehicle 
{
	protected String engine_type;
	protected String roch_type;
	protected String purpose;
	
	land()
	{
		engine_type = "Unknown";
		roch_type = "Unknown";
		purpose = "Unknown";
	}
	
	land(String engine_type, String roch_type, String purpose)
	{
		this.engine_type = engine_type;
		this.roch_type = roch_type;
		this.purpose = purpose;
	}
	
	public void drive()
	{
		System.out.println("Engine type: " + engine_type);
		System.out.println("Rolling Chassis type: " + roch_type);
		System.out.println("Vehicle's Main Purpose: " + purpose);
	}
}
